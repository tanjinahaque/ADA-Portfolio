# Articles saved for another project

Saved before removing the Articles section from the portfolio homepage.

- articles-section.html: exact original homepage section, including all card text and links.
- articles.html: complete article listing.
- article-*.html: all nine full articles, including their inline scripts.
- style.css: complete original stylesheet, including shared and responsive styles.
- index.html: original homepage for navigation, script, and layout reference.
- image/: original image assets.

Extract this ZIP into a separate project to reuse the content. Open articles.html to view the listing. Google Fonts still requires an internet connection. Adapt the homepage/contact links and portfolio-specific password gate for the new project.

The standalone article pages remain in the current portfolio; the homepage section and its desktop/mobile navigation links have been removed.
